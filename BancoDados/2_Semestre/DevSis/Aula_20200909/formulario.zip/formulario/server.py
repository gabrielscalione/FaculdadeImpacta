from flask import Flask, render_template, request, redirect, url_for
import json

# pip install flask

app = Flask(__name__,static_url_path='', static_folder='static',template_folder='templates')


@app.route('/', methods=['GET'])
def index():
    return render_template('formulario.html')

@app.route('/cadastro', methods=['POST'])
def teste():

    print(json.dumps(request.form.to_dict(), indent=4))

    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run()